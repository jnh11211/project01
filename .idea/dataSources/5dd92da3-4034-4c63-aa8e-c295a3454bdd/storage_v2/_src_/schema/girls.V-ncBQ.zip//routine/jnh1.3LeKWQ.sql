create procedure jnh1(IN beautyname varchar(20))
  BEGIN
SELECT b.*  FROM boys b RIGHT JOIN  beauty g 
ON g.`boyfriend_id`=b.id WHERE g.name=beautyname;
END;

