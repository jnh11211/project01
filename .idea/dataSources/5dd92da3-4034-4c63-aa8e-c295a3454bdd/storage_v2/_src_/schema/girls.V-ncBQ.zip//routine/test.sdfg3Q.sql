create procedure test(IN times int)
  BEGIN
      DECLARE i INT DEFAULT 1;
      a:WHILE i<=times DO 
      INSERT INTO  admin (username,`password`) VALUES(CONCAT('rose',i),'1111');
      SET i=i+1;
      END WHILE a;
      
END;

