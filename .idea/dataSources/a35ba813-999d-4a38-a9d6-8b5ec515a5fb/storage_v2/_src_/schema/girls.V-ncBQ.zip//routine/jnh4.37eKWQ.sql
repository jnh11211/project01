create procedure jnh4(IN beautyname varchar(20), OUT boyname varchar(20))
  BEGIN
SELECT boys.`boyName` INTO boyname FROM boys INNER JOIN beauty bv 
ON boys.`id`=bv.boyfriend_id WHERE bv.name=beautyname;
END;

