create procedure test1(IN times int)
  BEGIN
DECLARE i  INT DEFAULT  1;
a:WHILE i<=times DO 
INSERT INTO admin (username,`password`) VALUES(CONCAT('jack',i),'22222');
IF i>20 THEN LEAVE a;
END IF;
SET i=i+1;
END WHILE a;


END;

