create procedure jnh3(IN username varchar(20), IN PASSWORD varchar(20))
  BEGIN 
DECLARE result INT DEFAULT 0;
SELECT COUNT(*) INTO result 
FROM admin
WHERE admin.`username`=username AND admin.`password` =PASSWORD;
SELECT IF(result>0,'成功','失败');

END;

